#ifndef __IIC_H_
#define __IIC_H_

#include "system.h"

void write_dac(u8 dat);
u8 read_dac(u8 cb);

#endif
