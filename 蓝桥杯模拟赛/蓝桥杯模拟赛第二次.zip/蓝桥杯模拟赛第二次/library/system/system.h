#ifndef __SYSTEM_H_
#define __SYSTEM_H_

typedef unsigned char u8;
typedef unsigned int u16;
typedef unsigned long u32;

#include <STC15F2K60S2.H>
#include "P2P0.h"
#include "intrins.h"
#include "Timer.h"
#include "smg.h"
#include "kbd.h"
#include "iic.h"
#include "onewire.h"

#endif
